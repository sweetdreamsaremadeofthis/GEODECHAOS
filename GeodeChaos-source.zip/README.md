# Banana con queso chavales 💀

## Geode Chaos

A tiny Geometry Dash mod for Geode.

The mod adds a button to the main menu. Press it to receive a completely unnecessary random message.

### Build

The GitHub Actions workflow builds the Android64 package for Geometry Dash 2.2091.

1. Upload these files to the root of your `GEODECHAOS` repository.
2. Open the **Actions** tab.
3. Run **Build Geode Mod**, or push a commit to `main`.
4. Download the `GeodeChaos-Android64` artifact from a successful run.
