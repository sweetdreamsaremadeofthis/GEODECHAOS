#include <Geode/Geode.hpp>
#include <Geode/modify/MenuLayer.hpp>

using namespace geode::prelude;

class $modify(GeodeChaosMenuLayer, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) {
            return false;
        }

        auto menu = this->getChildByID("bottom-menu");
        if (!menu) {
            log::warn("Geode Chaos: bottom-menu was not found.");
            return true;
        }

        auto sprite = CCSprite::createWithSpriteFrameName("GJ_infoIcon_001.png");
        if (!sprite) {
            sprite = CCSprite::createWithSpriteFrameName("GJ_likeBtn_001.png");
        }
        if (!sprite) {
            log::warn("Geode Chaos: could not create the button sprite.");
            return true;
        }

        auto button = CCMenuItemSpriteExtra::create(
            sprite,
            this,
            menu_selector(GeodeChaosMenuLayer::onChaosButton)
        );
        button->setID("geode-chaos-button"_spr);
        menu->addChild(button);
        menu->updateLayout();

        return true;
    }

    void onChaosButton(CCObject*) {
        static constexpr const char* messages[] = {
            "Banana con queso chavales.",
            "El cubo esta pensando. Espera.",
            "Error 404: skill issue not found.",
            "Un momento, el ornitorrinco esta compilando.",
            "Geometria detectada. Procediendo a geometrizar.",
            "Este mensaje no aporta absolutamente nada.",
            "Mayonesa ha entrado al servidor."
        };

        auto index = rand() % (sizeof(messages) / sizeof(messages[0]));
        FLAlertLayer::create("Geode Chaos", messages[index], "OK")->show();
    }
};
